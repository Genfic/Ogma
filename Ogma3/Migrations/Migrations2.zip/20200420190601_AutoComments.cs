﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Ogma3.Migrations
{
    public partial class AutoComments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_CommentThreads_CommentsThreadId",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_Chapters_CommentsThreadId",
                table: "Chapters");

            migrationBuilder.DropIndex(
                name: "IX_Blogposts_CommentsThreadId",
                table: "Blogposts");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CommentsThreadId",
                table: "AspNetUsers");

            migrationBuilder.AddColumn<int>(
                name: "BlogpostId",
                table: "Comments",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ChapterId",
                table: "Comments",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "Comments",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Comments_BlogpostId",
                table: "Comments",
                column: "BlogpostId");

            migrationBuilder.CreateIndex(
                name: "IX_Comments_ChapterId",
                table: "Comments",
                column: "ChapterId");

            migrationBuilder.CreateIndex(
                name: "IX_Comments_UserId",
                table: "Comments",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Chapters_CommentsThreadId",
                table: "Chapters",
                column: "CommentsThreadId");

            migrationBuilder.CreateIndex(
                name: "IX_Blogposts_CommentsThreadId",
                table: "Blogposts",
                column: "CommentsThreadId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CommentsThreadId",
                table: "AspNetUsers",
                column: "CommentsThreadId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_CommentThreads_CommentsThreadId",
                table: "AspNetUsers",
                column: "CommentsThreadId",
                principalTable: "CommentThreads",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_Blogposts_BlogpostId",
                table: "Comments",
                column: "BlogpostId",
                principalTable: "Blogposts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_Chapters_ChapterId",
                table: "Comments",
                column: "ChapterId",
                principalTable: "Chapters",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_AspNetUsers_UserId",
                table: "Comments",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_CommentThreads_CommentsThreadId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Comments_Blogposts_BlogpostId",
                table: "Comments");

            migrationBuilder.DropForeignKey(
                name: "FK_Comments_Chapters_ChapterId",
                table: "Comments");

            migrationBuilder.DropForeignKey(
                name: "FK_Comments_AspNetUsers_UserId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Comments_BlogpostId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Comments_ChapterId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Comments_UserId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Chapters_CommentsThreadId",
                table: "Chapters");

            migrationBuilder.DropIndex(
                name: "IX_Blogposts_CommentsThreadId",
                table: "Blogposts");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CommentsThreadId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "BlogpostId",
                table: "Comments");

            migrationBuilder.DropColumn(
                name: "ChapterId",
                table: "Comments");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Comments");

            migrationBuilder.CreateIndex(
                name: "IX_Chapters_CommentsThreadId",
                table: "Chapters",
                column: "CommentsThreadId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Blogposts_CommentsThreadId",
                table: "Blogposts",
                column: "CommentsThreadId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CommentsThreadId",
                table: "AspNetUsers",
                column: "CommentsThreadId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_CommentThreads_CommentsThreadId",
                table: "AspNetUsers",
                column: "CommentsThreadId",
                principalTable: "CommentThreads",
                principalColumn: "Id");
        }
    }
}
