﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

namespace Ogma3.Migrations
{
    public partial class AllKeysToLongs : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Chapters_Stories_StoryId",
                table: "Chapters");

            migrationBuilder.DropForeignKey(
                name: "FK_Comments_CommentThreads_CommentsThreadId",
                table: "Comments");

            migrationBuilder.DropForeignKey(
                name: "FK_ShelfStories_Shelves_ShelfId",
                table: "ShelfStories");

            migrationBuilder.DropForeignKey(
                name: "FK_ShelfStories_Stories_StoryId",
                table: "ShelfStories");

            migrationBuilder.DropForeignKey(
                name: "FK_Shelves_Icons_IconId",
                table: "Shelves");

            migrationBuilder.DropForeignKey(
                name: "FK_Votes_VotePools_VotePoolId",
                table: "Votes");

            migrationBuilder.DropIndex(
                name: "IX_Votes_VotePoolId",
                table: "Votes");

            migrationBuilder.DropIndex(
                name: "IX_Shelves_IconId",
                table: "Shelves");

            migrationBuilder.DropIndex(
                name: "IX_ShelfStories_StoryId",
                table: "ShelfStories");

            migrationBuilder.DropIndex(
                name: "IX_Comments_CommentsThreadId",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Chapters_StoryId",
                table: "Chapters");

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Votes",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<long>(
                name: "VotePoolId1",
                table: "Votes",
                nullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "VotePools",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "NamespaceId",
                table: "Tags",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "integer",
                oldNullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Tags",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "TagId",
                table: "StoryTags",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<long>(
                name: "StoryId",
                table: "StoryTags",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<long>(
                name: "VotesPoolId",
                table: "Stories",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Stories",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Shelves",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<long>(
                name: "IconId1",
                table: "Shelves",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "ShelfId1",
                table: "ShelfStories",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "StoryId1",
                table: "ShelfStories",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Quotes",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Namespaces",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "InviteCode",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Icons",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "CommentThreads",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AddColumn<long>(
                name: "CommentsThreadId1",
                table: "Comments",
                nullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "CommentsThreadId",
                table: "Chapters",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AddColumn<long>(
                name: "StoryId1",
                table: "Chapters",
                nullable: true);

            migrationBuilder.AlterColumn<long>(
                name: "CommentsThreadId",
                table: "Blogposts",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.AlterColumn<long>(
                name: "Id",
                table: "Blogposts",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<long>(
                name: "CommentsThreadId",
                table: "AspNetUsers",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer");

            migrationBuilder.CreateIndex(
                name: "IX_Votes_VotePoolId1",
                table: "Votes",
                column: "VotePoolId1");

            migrationBuilder.CreateIndex(
                name: "IX_Shelves_IconId1",
                table: "Shelves",
                column: "IconId1");

            migrationBuilder.CreateIndex(
                name: "IX_ShelfStories_ShelfId1",
                table: "ShelfStories",
                column: "ShelfId1");

            migrationBuilder.CreateIndex(
                name: "IX_ShelfStories_StoryId1",
                table: "ShelfStories",
                column: "StoryId1");

            migrationBuilder.CreateIndex(
                name: "IX_Comments_CommentsThreadId1",
                table: "Comments",
                column: "CommentsThreadId1");

            migrationBuilder.CreateIndex(
                name: "IX_Chapters_StoryId1",
                table: "Chapters",
                column: "StoryId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Chapters_Stories_StoryId1",
                table: "Chapters",
                column: "StoryId1",
                principalTable: "Stories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_CommentThreads_CommentsThreadId1",
                table: "Comments",
                column: "CommentsThreadId1",
                principalTable: "CommentThreads",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ShelfStories_Shelves_ShelfId1",
                table: "ShelfStories",
                column: "ShelfId1",
                principalTable: "Shelves",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ShelfStories_Stories_StoryId1",
                table: "ShelfStories",
                column: "StoryId1",
                principalTable: "Stories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Shelves_Icons_IconId1",
                table: "Shelves",
                column: "IconId1",
                principalTable: "Icons",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Votes_VotePools_VotePoolId1",
                table: "Votes",
                column: "VotePoolId1",
                principalTable: "VotePools",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Chapters_Stories_StoryId1",
                table: "Chapters");

            migrationBuilder.DropForeignKey(
                name: "FK_Comments_CommentThreads_CommentsThreadId1",
                table: "Comments");

            migrationBuilder.DropForeignKey(
                name: "FK_ShelfStories_Shelves_ShelfId1",
                table: "ShelfStories");

            migrationBuilder.DropForeignKey(
                name: "FK_ShelfStories_Stories_StoryId1",
                table: "ShelfStories");

            migrationBuilder.DropForeignKey(
                name: "FK_Shelves_Icons_IconId1",
                table: "Shelves");

            migrationBuilder.DropForeignKey(
                name: "FK_Votes_VotePools_VotePoolId1",
                table: "Votes");

            migrationBuilder.DropIndex(
                name: "IX_Votes_VotePoolId1",
                table: "Votes");

            migrationBuilder.DropIndex(
                name: "IX_Shelves_IconId1",
                table: "Shelves");

            migrationBuilder.DropIndex(
                name: "IX_ShelfStories_ShelfId1",
                table: "ShelfStories");

            migrationBuilder.DropIndex(
                name: "IX_ShelfStories_StoryId1",
                table: "ShelfStories");

            migrationBuilder.DropIndex(
                name: "IX_Comments_CommentsThreadId1",
                table: "Comments");

            migrationBuilder.DropIndex(
                name: "IX_Chapters_StoryId1",
                table: "Chapters");

            migrationBuilder.DropColumn(
                name: "VotePoolId1",
                table: "Votes");

            migrationBuilder.DropColumn(
                name: "IconId1",
                table: "Shelves");

            migrationBuilder.DropColumn(
                name: "ShelfId1",
                table: "ShelfStories");

            migrationBuilder.DropColumn(
                name: "StoryId1",
                table: "ShelfStories");

            migrationBuilder.DropColumn(
                name: "CommentsThreadId1",
                table: "Comments");

            migrationBuilder.DropColumn(
                name: "StoryId1",
                table: "Chapters");

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Votes",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "VotePools",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "NamespaceId",
                table: "Tags",
                type: "integer",
                nullable: true,
                oldClrType: typeof(long),
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Tags",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "TagId",
                table: "StoryTags",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long));

            migrationBuilder.AlterColumn<int>(
                name: "StoryId",
                table: "StoryTags",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long));

            migrationBuilder.AlterColumn<int>(
                name: "VotesPoolId",
                table: "Stories",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long));

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Stories",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Shelves",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Quotes",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Namespaces",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "InviteCode",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Icons",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "CommentThreads",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "CommentsThreadId",
                table: "Chapters",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long));

            migrationBuilder.AlterColumn<int>(
                name: "CommentsThreadId",
                table: "Blogposts",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long));

            migrationBuilder.AlterColumn<int>(
                name: "Id",
                table: "Blogposts",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long))
                .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn)
                .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

            migrationBuilder.AlterColumn<int>(
                name: "CommentsThreadId",
                table: "AspNetUsers",
                type: "integer",
                nullable: false,
                oldClrType: typeof(long));

            migrationBuilder.CreateIndex(
                name: "IX_Votes_VotePoolId",
                table: "Votes",
                column: "VotePoolId");

            migrationBuilder.CreateIndex(
                name: "IX_Shelves_IconId",
                table: "Shelves",
                column: "IconId");

            migrationBuilder.CreateIndex(
                name: "IX_ShelfStories_StoryId",
                table: "ShelfStories",
                column: "StoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Comments_CommentsThreadId",
                table: "Comments",
                column: "CommentsThreadId");

            migrationBuilder.CreateIndex(
                name: "IX_Chapters_StoryId",
                table: "Chapters",
                column: "StoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_Chapters_Stories_StoryId",
                table: "Chapters",
                column: "StoryId",
                principalTable: "Stories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Comments_CommentThreads_CommentsThreadId",
                table: "Comments",
                column: "CommentsThreadId",
                principalTable: "CommentThreads",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ShelfStories_Shelves_ShelfId",
                table: "ShelfStories",
                column: "ShelfId",
                principalTable: "Shelves",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ShelfStories_Stories_StoryId",
                table: "ShelfStories",
                column: "StoryId",
                principalTable: "Stories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Shelves_Icons_IconId",
                table: "Shelves",
                column: "IconId",
                principalTable: "Icons",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Votes_VotePools_VotePoolId",
                table: "Votes",
                column: "VotePoolId",
                principalTable: "VotePools",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
